package com.example.aihub

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Html
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import org.json.JSONObject
import java.util.UUID
import kotlin.coroutines.resume

private val BG = 0xFFFAF9F5.toInt()
private val INK = 0xFF1F1E1D.toInt()
private val SUB = 0xFF8A877D.toInt()
private val ORANGE = 0xFFD97757.toInt()
private val USERBG = 0xFFF0EEE6.toInt()
private val LINE = 0xFFE5E2D8.toInt()
private val CARD = 0xFFF5F4EE.toInt()

private val CLAUDE_CFG = """{input:['div[contenteditable="true"].ProseMirror','div[contenteditable="true"]'],send:['button[aria-label="Send message"]','button[aria-label="메시지 보내기"]','button[aria-label*="Send"]'],resp:['[data-is-streaming]','.font-claude-response','.font-claude-message'],stop:['button[aria-label*="Stop"]','button[aria-label*="중지"]']}"""
private val CHATGPT_CFG = """{input:['#prompt-textarea','div[contenteditable="true"]'],send:['button[data-testid="send-button"]','button[aria-label*="Send"]','button[aria-label*="전송"]'],resp:['[data-message-author-role="assistant"]'],stop:['button[data-testid="stop-button"]','button[aria-label*="Stop"]','button[aria-label*="중지"]']}"""

private val GEMINI_CFG = """{input:['div.ql-editor[contenteditable="true"]','rich-textarea div[contenteditable="true"]','div[contenteditable="true"]'],send:['button.send-button','button[aria-label="Send message"]','button[aria-label="메시지 보내기"]','button[aria-label*="Send"]'],resp:['message-content','.model-response-text','.markdown'],stop:['button[aria-label*="Stop"]','button[aria-label*="중지"]','button.stop']}"""

// 각 AI 사이트 페이지 안에서 돌면서 입력 → 전송 → 답변 읽기를 해주는 스크립트
private val WORKER_JS = """
(function(){
if(window.__gh)return;
var CFG=%CFG%;
var LIM=/usage limit|message limit|limit reached|too many requests|reached (your|the) .*limit|사용량 한도|한도에 도달|이용 한도/i;
function q(list,all){for(var i=0;i<list.length;i++){var e=all?Array.prototype.slice.call(document.querySelectorAll(list[i])):document.querySelector(list[i]);if(all?e.length:e)return e;}return all?[]:null;}
function sleep(ms){return new Promise(function(r){setTimeout(r,ms);});}
function lastEl(){var l=q(CFG.resp,true);return l[l.length-1];}
async function run(prompt){
 var inp=q(CFG.input);
 if(!inp)return {error:'입력창을 찾지 못했어요 (로그인이 필요할 수 있어요)'};
 var before=q(CFG.resp,true).length;var le=lastEl();var beforeTxt=le?le.innerText.trim():'';
 inp.focus();document.execCommand('selectAll');document.execCommand('insertText',false,prompt);
 await sleep(700);
 var btn=q(CFG.send);
 if(btn&&!btn.disabled)btn.click();else inp.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true}));
 var start=Date.now(),last='',stable=0;
 while(Date.now()-start<190000){
  await sleep(800);
  var el=lastEl();var txt=el?el.innerText.trim():'';
  if(!txt||(q(CFG.resp,true).length<=before&&txt===beforeTxt))continue;
  var streaming=!!q(CFG.stop)||el.getAttribute('data-is-streaming')==='true';
  if(txt===last&&!streaming)stable++;else{stable=0;last=txt;}
  if(stable>=4)break;
 }
 if(!last)return {error:'응답을 읽지 못했어요',limit:LIM.test(document.body.innerText.slice(-1500))};
 if(last.length<400&&LIM.test(last))return {error:'limit',limit:true};
 return {text:last};
}
window.__gh=function(id,prompt){run(prompt).then(function(r){Android.onResult(id,JSON.stringify(r));}).catch(function(e){Android.onResult(id,JSON.stringify({error:String(e)}));});};
})();
"""

private val EXT = mapOf(
    "js" to "js", "javascript" to "js", "html" to "html", "css" to "css", "json" to "json",
    "python" to "py", "py" to "py", "java" to "java", "kotlin" to "kt", "ts" to "ts",
    "typescript" to "ts", "md" to "md", "bash" to "sh", "sh" to "sh", "xml" to "xml", "sql" to "sql"
)

class Msg(val role: String, val who: String, var text: String)

class Prov(val key: String, val label: String, val base: String, val cfg: String, val aliases: List<String>) {
    lateinit var web: WebView
}

class MainActivity : AppCompatActivity() {
    private val claude = Prov("claude", "Claude", "https://claude.ai/new", CLAUDE_CFG, listOf("claude", "클로드"))
    private val chatgpt = Prov("chatgpt", "ChatGPT", "https://chatgpt.com/", CHATGPT_CFG, listOf("chatgpt", "gpt", "지피티", "챗지피티"))
    private val gemini = Prov("gemini", "Gemini", "https://gemini.google.com/app", GEMINI_CFG, listOf("gemini", "제미나이"))
    private val all = listOf(claude, chatgpt, gemini)

    private val scope = MainScope()
    private val handler = Handler(Looper.getMainLooper())
    private val pending = HashMap<String, (String) -> Unit>()
    private val msgs = ArrayList<Msg>()
    private val limited = HashMap<String, Boolean>()
    private val warned = HashMap<String, Boolean>()
    private var mode = 0
    private var rounds = 1
    private var busy = false
    private var loginOpen = false
    private var loginProv: Prov? = null

    private lateinit var main: LinearLayout
    private lateinit var webHost: LinearLayout
    private lateinit var webFrame: FrameLayout
    private lateinit var loginBar: LinearLayout
    private lateinit var loginTitle: TextView
    private lateinit var rv: RecyclerView
    private lateinit var input: EditText
    private lateinit var chip: TextView

    private val modeNames = arrayOf("Claude", "ChatGPT", "Gemini", "모두 (각자 답)", "모두 토론")
    private val modeChips = arrayOf("Claude ▾", "ChatGPT ▾", "Gemini ▾", "모두 ▾", "토론 ▾")

    private val adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        override fun getItemCount() = msgs.size
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val c = LinearLayout(parent.context)
            c.orientation = LinearLayout.VERTICAL
            c.layoutParams = RecyclerView.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
            return object : RecyclerView.ViewHolder(c) {}
        }
        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            bind(holder.itemView as LinearLayout, msgs[position])
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun onResult(id: String, json: String) {
            runOnUiThread { pending.remove(id)?.invoke(json) }
        }
    }

    // ------------------------------------------------------------ 화면
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        for (p in all) setupWeb(p)
        addNote("안녕하세요! 먼저 ☰ 메뉴에서 Claude, ChatGPT, Gemini에 로그인해 주세요.\n@claude, @chatgpt, @gemini 로 시작하면 그 AI만 답해요.")
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun lp(w: Int, h: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, h, wt)
    private fun bg(color: Int, r: Int, stroke: Int = 0, sc: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(r).toFloat()
        if (stroke > 0) g.setStroke(dp(stroke), sc)
        return g
    }
    private fun tv(t: String, size: Float, color: Int = INK): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        return v
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun copy(s: String) {
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("t", s))
        toast("복사했어요")
    }

    private fun iconBtn(t: String, click: () -> Unit): TextView {
        val v = tv(t, 22f)
        v.gravity = Gravity.CENTER
        v.layoutParams = lp(dp(44), dp(44))
        v.setOnClickListener { click() }
        return v
    }

    private fun buildUi() {
        val root = FrameLayout(this)
        root.setBackgroundColor(BG)

        // 로그인용 웹뷰 영역 (평소엔 뒤에 숨어서 AI 사이트와 통신만 함)
        webHost = LinearLayout(this)
        webHost.orientation = LinearLayout.VERTICAL
        webHost.setBackgroundColor(Color.WHITE)
        webHost.alpha = 0.01f
        loginBar = LinearLayout(this)
        loginBar.orientation = LinearLayout.HORIZONTAL
        loginBar.gravity = Gravity.CENTER_VERTICAL
        loginBar.setBackgroundColor(BG)
        loginBar.setPadding(dp(16), 0, dp(8), 0)
        loginBar.visibility = View.GONE
        loginTitle = tv("로그인", 16f)
        loginTitle.typeface = Typeface.DEFAULT_BOLD
        val closeBtn = tv("완료", 15f, ORANGE)
        closeBtn.setPadding(dp(16), dp(10), dp(16), dp(10))
        closeBtn.setOnClickListener { closeLogin() }
        loginBar.addView(loginTitle, lp(0, WRAP_CONTENT, 1f))
        loginBar.addView(closeBtn, lp(WRAP_CONTENT, WRAP_CONTENT))
        webFrame = FrameLayout(this)
        webHost.addView(loginBar, lp(MATCH_PARENT, dp(52)))
        webHost.addView(webFrame, lp(MATCH_PARENT, 0, 1f))
        root.addView(webHost, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        // 메인 채팅 화면
        main = LinearLayout(this)
        main.orientation = LinearLayout.VERTICAL
        main.setBackgroundColor(BG)
        main.isClickable = true

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.setPadding(dp(8), dp(4), dp(8), dp(4))
        top.addView(iconBtn("☰") { menu() })
        val title = tv("AI 허브", 20f)
        title.typeface = Typeface.SERIF
        title.gravity = Gravity.CENTER
        top.addView(title, lp(0, WRAP_CONTENT, 1f))
        top.addView(iconBtn("✎") { newChat() })
        main.addView(top, lp(MATCH_PARENT, WRAP_CONTENT))

        rv = RecyclerView(this)
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = adapter
        rv.clipToPadding = false
        rv.setPadding(dp(16), dp(8), dp(16), dp(8))
        main.addView(rv, lp(MATCH_PARENT, 0, 1f))

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = bg(Color.WHITE, 24, 1, LINE)
        card.setPadding(dp(16), dp(10), dp(10), dp(10))
        card.elevation = dp(2).toFloat()
        input = EditText(this)
        input.hint = "무엇이든 물어보세요  (@claude @chatgpt @gemini)"
        input.setHintTextColor(SUB)
        input.setTextColor(INK)
        input.background = null
        input.textSize = 16f
        input.maxLines = 5
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        card.addView(input, lp(MATCH_PARENT, WRAP_CONTENT))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val plus = tv("+", 22f)
        plus.gravity = Gravity.CENTER
        plus.background = bg(Color.WHITE, 20, 1, LINE)
        plus.setOnClickListener { mentionMenu() }
        row.addView(plus, lp(dp(40), dp(40)))
        chip = tv(modeChips[0], 14f)
        chip.background = bg(USERBG, 20)
        chip.setPadding(dp(16), dp(9), dp(16), dp(9))
        chip.setOnClickListener { modeMenu() }
        val cl = lp(WRAP_CONTENT, WRAP_CONTENT)
        cl.leftMargin = dp(8)
        row.addView(chip, cl)
        row.addView(View(this), lp(0, 1, 1f))
        val sendBtn = tv("↑", 22f, Color.WHITE)
        sendBtn.gravity = Gravity.CENTER
        sendBtn.typeface = Typeface.DEFAULT_BOLD
        sendBtn.background = bg(ORANGE, 20)
        sendBtn.setOnClickListener { send() }
        row.addView(sendBtn, lp(dp(40), dp(40)))
        card.addView(row, lp(MATCH_PARENT, WRAP_CONTENT))
        val cardLp = lp(MATCH_PARENT, WRAP_CONTENT)
        cardLp.setMargins(dp(12), dp(4), dp(12), dp(12))
        main.addView(card, cardLp)

        root.addView(main, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        setContentView(root)
    }

    // ------------------------------------------------------------ 메시지 표시
    private fun addMsg(m: Msg) {
        msgs.add(m)
        adapter.notifyItemInserted(msgs.size - 1)
        rv.post { rv.scrollToPosition(msgs.size - 1) }
    }
    private fun addNote(t: String) = addMsg(Msg("note", "", t))
    private fun refresh(m: Msg) {
        val i = msgs.indexOf(m)
        if (i >= 0) adapter.notifyItemChanged(i)
        rv.post { rv.scrollToPosition(msgs.size - 1) }
    }

    private fun bind(c: LinearLayout, m: Msg) {
        c.removeAllViews()
        when (m.role) {
            "user" -> {
                val t = tv(m.text, 16f)
                t.background = bg(USERBG, 18)
                t.setPadding(dp(14), dp(10), dp(14), dp(10))
                t.setTextIsSelectable(true)
                val l = lp(WRAP_CONTENT, WRAP_CONTENT)
                l.gravity = Gravity.END
                l.leftMargin = dp(48)
                l.topMargin = dp(10)
                c.addView(t, l)
            }
            "note" -> {
                val t = tv(m.text, 13f, SUB)
                t.gravity = Gravity.CENTER
                val l = lp(MATCH_PARENT, WRAP_CONTENT)
                l.topMargin = dp(12)
                c.addView(t, l)
            }
            else -> {
                val who = tv(m.who, 13f, ORANGE)
                who.typeface = Typeface.DEFAULT_BOLD
                val wl = lp(WRAP_CONTENT, WRAP_CONTENT)
                wl.topMargin = dp(14)
                c.addView(who, wl)
                renderRich(c, m.text)
                if (m.text != "생각 중…") {
                    val a = tv("복사", 13f, SUB)
                    a.setPadding(0, dp(8), dp(12), dp(4))
                    a.setOnClickListener { copy(m.text) }
                    c.addView(a, lp(WRAP_CONTENT, WRAP_CONTENT))
                }
            }
        }
    }

    private fun md(s: String): String {
        var h = TextUtils.htmlEncode(s.trim())
        h = h.replace(Regex("(?m)^#{1,3} (.*)$"), "<b>$1</b>")
        h = h.replace(Regex("\\*\\*(.+?)\\*\\*"), "<b>$1</b>")
        h = h.replace(Regex("`([^`\\n]+)`"), "<tt>$1</tt>")
        return h.replace("\n", "<br>")
    }

    private fun addText(c: LinearLayout, s: String) {
        if (s.isBlank()) return
        val t = tv("", 16f)
        t.text = Html.fromHtml(md(s), Html.FROM_HTML_MODE_COMPACT)
        t.setLineSpacing(0f, 1.15f)
        t.setTextIsSelectable(true)
        val l = lp(MATCH_PARENT, WRAP_CONTENT)
        l.topMargin = dp(4)
        c.addView(t, l)
    }

    private fun renderRich(c: LinearLayout, text: String) {
        val re = Regex("```(\\w*)\\n([\\s\\S]*?)```")
        var last = 0
        var n = 0
        for (m in re.findAll(text)) {
            addText(c, text.substring(last, m.range.first))
            last = m.range.last + 1
            n++
            val ext = EXT[m.groupValues[1].lowercase()] ?: "txt"
            addCodeCard(c, "result$n.$ext", m.groupValues[2].trim('\n'))
        }
        addText(c, text.substring(last))
    }

    // 파일 카드
    private fun addCodeCard(c: LinearLayout, name: String, code: String) {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = bg(CARD, 12, 1, LINE)
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(12), dp(6), dp(6), dp(6))
        val nm = tv("📄 $name", 14f)
        nm.typeface = Typeface.DEFAULT_BOLD
        head.addView(nm, lp(0, WRAP_CONTENT, 1f))
        val b1 = tv("복사", 13f, ORANGE)
        b1.setPadding(dp(10), dp(6), dp(10), dp(6))
        b1.setOnClickListener { copy(code) }
        val b2 = tv("공유", 13f, ORANGE)
        b2.setPadding(dp(10), dp(6), dp(10), dp(6))
        b2.setOnClickListener {
            val i = Intent(Intent.ACTION_SEND)
            i.type = "text/plain"
            i.putExtra(Intent.EXTRA_TEXT, code)
            i.putExtra(Intent.EXTRA_SUBJECT, name)
            startActivity(Intent.createChooser(i, name))
        }
        head.addView(b1, lp(WRAP_CONTENT, WRAP_CONTENT))
        head.addView(b2, lp(WRAP_CONTENT, WRAP_CONTENT))
        val body = tv(code, 12f)
        body.typeface = Typeface.MONOSPACE
        body.setPadding(dp(12), dp(4), dp(12), dp(10))
        body.maxLines = 10
        body.ellipsize = TextUtils.TruncateAt.END
        body.setOnClickListener { body.maxLines = if (body.maxLines == 10) 1000 else 10 }
        card.addView(head, lp(MATCH_PARENT, WRAP_CONTENT))
        card.addView(body, lp(MATCH_PARENT, WRAP_CONTENT))
        val l = lp(MATCH_PARENT, WRAP_CONTENT)
        l.topMargin = dp(8)
        l.bottomMargin = dp(4)
        c.addView(card, l)
    }

    // ------------------------------------------------------------ 메뉴
    private fun menu() {
        val items = arrayOf("🔑 Claude 로그인", "🔑 ChatGPT 로그인", "🔑 Gemini 로그인", "🗑 새 대화", "🔁 토론 라운드: $rounds (누르면 변경)", "ℹ️ 사용법")
        AlertDialog.Builder(this).setItems(items) { _, w ->
            when (w) {
                0 -> openLogin(claude)
                1 -> openLogin(chatgpt)
                2 -> openLogin(gemini)
                3 -> newChat()
                4 -> { rounds = rounds % 3 + 1; toast("토론 라운드: $rounds") }
                5 -> AlertDialog.Builder(this).setMessage(
                    "1. ☰ → 로그인에서 각 AI에 로그인하고 '완료'를 눌러요.\n" +
                    "2. 아래 칩에서 AI를 고르거나, 메시지 앞에 @claude / @chatgpt / @gemini 를 붙이면 그 AI만 답해요.\n" +
                    "3. '모두 토론'을 고르면 AI들이 서로 의견을 주고받고 최종 결과를 만들어요.\n" +
                    "4. 코드는 파일 카드로 나오고 복사·공유할 수 있어요.\n" +
                    "5. AI 사용량이 끝나면 한 번만 알려주고 그 AI는 건너뛰어요."
                ).setPositiveButton("확인", null).show()
            }
        }.show()
    }
    private fun modeMenu() {
        AlertDialog.Builder(this).setItems(modeNames) { _, w ->
            mode = w
            chip.text = modeChips[w]
        }.show()
    }
    private fun mentionMenu() {
        val items = arrayOf("@claude", "@chatgpt", "@gemini", "@claude @chatgpt @gemini")
        AlertDialog.Builder(this).setTitle("호출할 AI").setItems(items) { _, w ->
            input.append(items[w] + " ")
            input.requestFocus()
        }.show()
    }
    private fun newChat() {
        msgs.clear()
        adapter.notifyDataSetChanged()
        limited.clear()
        warned.clear()
        for (p in all) p.web.loadUrl(p.base)
        addNote("새 대화를 시작했어요.")
    }

    // ------------------------------------------------------------ 웹뷰(각 AI 사이트)
    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWeb(p: Prov) {
        val w = WebView(this)
        p.web = w
        val st = w.settings
        st.javaScriptEnabled = true
        st.domStorageEnabled = true
        st.userAgentString = st.userAgentString.replace("; wv", "").replace(Regex("Version/\\d+\\.\\d+ "), "")
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)
        w.addJavascriptInterface(Bridge(), "Android")
        w.webChromeClient = WebChromeClient()
        w.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String?) {
                view.evaluateJavascript(WORKER_JS.replace("%CFG%", p.cfg), null)
                CookieManager.getInstance().flush()
            }
        }
        webFrame.addView(w, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        w.loadUrl(p.base)
    }

    private fun openLogin(p: Prov) {
        loginProv = p
        loginTitle.text = p.label + " 로그인"
        loginBar.visibility = View.VISIBLE
        for (o in all) o.web.visibility = if (o === p) View.VISIBLE else View.INVISIBLE
        webHost.alpha = 1f
        webHost.bringToFront()
        loginOpen = true
    }
    private fun closeLogin() {
        loginBar.visibility = View.GONE
        for (o in all) o.web.visibility = View.VISIBLE
        webHost.alpha = 0.01f
        main.bringToFront()
        loginOpen = false
        loginProv?.web?.loadUrl(loginProv!!.base)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val p = loginProv
        if (loginOpen && p != null) {
            if (p.web.canGoBack()) p.web.goBack() else closeLogin()
        } else {
            @Suppress("DEPRECATION")
            super.onBackPressed()
        }
    }

    override fun onPause() {
        super.onPause()
        CookieManager.getInstance().flush()
    }
    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    // ------------------------------------------------------------ AI 호출
    private suspend fun raw(p: Prov, prompt: String): JSONObject = suspendCancellableCoroutine { cont ->
        val id = UUID.randomUUID().toString()
        val timeout = Runnable {
            if (pending.remove(id) != null && cont.isActive) cont.resume(JSONObject("{\"error\":\"시간 초과\"}"))
        }
        pending[id] = { json ->
            handler.removeCallbacks(timeout)
            if (cont.isActive) cont.resume(JSONObject(json))
        }
        handler.postDelayed(timeout, 200000)
        cont.invokeOnCancellation {
            pending.remove(id)
            handler.removeCallbacks(timeout)
        }
        p.web.evaluateJavascript("typeof window.__gh") { r ->
            if (r != "\"function\"") {
                pending.remove(id)
                handler.removeCallbacks(timeout)
                if (cont.isActive) cont.resume(JSONObject("{\"error\":\"페이지가 아직 준비되지 않았어요. 잠시 후 다시 시도하세요\"}"))
            } else {
                p.web.evaluateJavascript("window.__gh(" + JSONObject.quote(id) + "," + JSONObject.quote(prompt) + ")", null)
            }
        }
    }

    private suspend fun askInto(p: Prov, prompt: String): String? {
        if (limited[p.key] == true) return null
        val m = Msg("ai", p.label, "생각 중…")
        addMsg(m)
        val r = raw(p, prompt)
        val text = r.optString("text", "")
        if (text.isNotEmpty()) {
            m.text = text
            refresh(m)
            return text
        }
        val i = msgs.indexOf(m)
        if (i >= 0) {
            msgs.removeAt(i)
            adapter.notifyItemRemoved(i)
        }
        if (r.optBoolean("limit")) {
            limited[p.key] = true
            if (warned[p.key] != true) {
                warned[p.key] = true
                addNote("⚠️ " + p.label + " 사용량 한도에 도달했습니다")
            }
            return null
        }
        val err = r.optString("error", "응답 없음")
        addNote("⚠️ " + p.label + ": " + err + (if (err.contains("입력창")) "  (☰ → 로그인에서 로그인하세요)" else ""))
        return null
    }

    private fun send() {
        if (busy) return
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        input.setText("")
        addMsg(Msg("user", "나", t))
        busy = true
        scope.launch {
            try {
                runAI(t)
            } finally {
                busy = false
            }
        }
    }

    private suspend fun runAI(rawText: String) {
        val found = ArrayList<Prov>()
        val prompt = Regex("@([A-Za-z가-힣]+)").replace(rawText) { mr ->
            val w = mr.groupValues[1].lowercase()
            val p = all.find { w in it.aliases }
            if (p != null) {
                if (!found.contains(p)) found.add(p)
                ""
            } else mr.value
        }.trim()
        if (prompt.isEmpty()) {
            addNote("요청 내용을 같이 적어주세요")
            return
        }
        var active: List<Prov> = if (found.isNotEmpty()) found.toList() else when (mode) {
            0 -> listOf(claude)
            1 -> listOf(chatgpt)
            2 -> listOf(gemini)
            else -> all
        }
        active = active.filter { limited[it.key] != true }
        if (active.isEmpty()) {
            addNote("사용할 수 있는 AI가 없어요 (사용량 한도 도달)")
            return
        }
        val ans = HashMap<String, String>()
        coroutineScope {
            active.map { p -> async { val t = askInto(p, prompt); if (t != null) ans[p.key] = t } }.awaitAll()
        }
        if (mode != 4 || active.size < 2) return
        var live = active.filter { ans.containsKey(it.key) }
        if (live.size < 2) {
            addNote("토론은 두 개 이상의 AI가 답해야 해요")
            return
        }
        for (r in 1..rounds) {
            if (live.size < 2) break
            addNote("💬 토론 " + r + "라운드")
            for (p in live.toList()) {
                val others = live.filter { it !== p }.joinToString("\n\n") { "[" + it.label + "]\n" + ans[it.key] }
                val t = askInto(p, "원래 요청: " + prompt + "\n\n다른 AI의 최근 의견:\n" + others + "\n\n장점은 인정하고 부족한 점은 짚으면서, 더 나은 아이디어나 개선안을 짧게 제시해줘.")
                if (t != null) ans[p.key] = t else live = live.filter { it !== p }
            }
        }
        for (p in live) {
            addNote("✅ 최종 결과")
            val t = askInto(p, "지금까지의 토론을 종합해서 원래 요청에 대한 최종 결과물을 만들어줘. 코드가 있으면 완성된 코드 블록으로 줘.")
            if (t != null) break
        }
    }
}
