package com.example.aihub

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.Html
import android.text.InputType
import android.text.TextUtils
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.resume

private val BG = 0xFFFAF9F5.toInt()
private val INK = 0xFF1F1E1D.toInt()
private val SUB = 0xFF8A877D.toInt()
private val ORANGE = 0xFFD97757.toInt()
private val USERBG = 0xFFF0EEE6.toInt()
private val LINE = 0xFFE5E2D8.toInt()
private val CARD = 0xFFF5F4EE.toInt()

private val CLAUDE_CFG = """{input:['[data-testid="chat-input"]','div[contenteditable="true"].ProseMirror','div[contenteditable="true"]'],send:['button[aria-label="Send message"]','button[aria-label="Send Message"]','button[aria-label="메시지 보내기"]','button[data-testid="send-button"]','button[aria-label*="Send"]'],resp:['[data-is-streaming]','[data-testid="assistant-message"]','.font-claude-response','.font-claude-message'],stop:['button[aria-label*="Stop"]','button[aria-label*="중지"]']}"""

private val GEMINI_CFG = """{input:['div.ql-editor[contenteditable="true"]','rich-textarea div[contenteditable="true"]','div[contenteditable="true"]'],send:['button.send-button','button[aria-label="Send message"]','button[aria-label="메시지 보내기"]','button[aria-label*="Send"]'],resp:['message-content','.model-response-text','.markdown'],stop:['button[aria-label*="Stop"]','button[aria-label*="중지"]','button.stop']}"""

// 각 AI 사이트 페이지 안에서 돌면서 입력 → 전송 → 답변 읽기를 해주는 스크립트
private val WORKER_JS = """
(function(){
if(window.__gh)return;
var CFG=%CFG%;
var LIM=/usage limit|message limit|limit reached|too many requests|reached (your|the) .*limit|사용량 한도|한도에 도달|이용 한도/i;
function q(list,all){for(var i=0;i<list.length;i++){var e=all?Array.prototype.slice.call(document.querySelectorAll(list[i])):document.querySelector(list[i]);if(all?e.length:e)return e;}return all?[]:null;}
function sleep(ms){return new Promise(function(r){setTimeout(r,ms);});}
function lastEl(){var l=q(CFG.resp,true);return l[l.length-1];}
function clean(t){
 t=(t||'').replace(/[\uE000-\uF8FF\u200B-\u200D\uFEFF]/g,'').replace(/^\s*(ChatGPT의 말|ChatGPT said|Claude 응답|Claude responded|Gemini의 말|Gemini said)\s*[:：]\s*/i,'');
 var lines=t.split('\n');
 while(lines.length&&(lines[lines.length-1].trim()===''||/^\s*(지금|방금|just now|now|\d+\s*(초|분|시간|일)\s*전|복사|다시 시도|retry|copy|공유|share)\s*$/i.test(lines[lines.length-1])||/^\s*[^\sA-Za-z0-9가-힣.!?,)\]"'~]{1,3}\s*$/.test(lines[lines.length-1])))lines.pop();
 t=lines.join('\n').replace(/\n{3,}/g,'\n\n').trim();
 var parts=t.split(/\n\n+/);
 if(parts.length>1){var a=parts[0].trim(),b=parts[1].trim();if(a&&b.length>a.length&&b.indexOf(a)===0)parts.shift();}
 return parts.join('\n\n').trim();
}
function inner(node){
 var hid=[];
 try{node.querySelectorAll('button,[role="button"],svg,.sr-only,[class*="sr-only"]').forEach(function(x){hid.push([x,x.style.display]);x.style.display='none';});}catch(e){}
 var s=node.innerText||'';
 hid.forEach(function(h){h[0].style.display=h[1];});
 return s;
}
function textOf(el){
 if(!el)return '';
 var r=el.querySelectorAll?el.querySelectorAll('.font-claude-response,.font-claude-message'):[];
 var s;
 if(r.length){
  var arr=Array.prototype.slice.call(r).filter(function(x){return !Array.prototype.some.call(r,function(y){return y!==x&&y.contains(x);});});
  s=arr.map(inner).join('\n\n');
 }else s=inner(el);
 return clean(s);
}
function findCanvas(){var l=document.querySelectorAll('button,[role="button"],[role="menuitem"],[role="option"],mat-chip,toolbox-drawer-item');for(var i=0;i<l.length;i++){var t=(l[i].innerText||'')+' '+(l[i].getAttribute('aria-label')||'');if(/canvas|캔버스/i.test(t))return l[i];}return null;}
async function enableCanvas(){var b=findCanvas();if(!b){var bs=document.querySelectorAll('button');for(var i=0;i<bs.length;i++){var t=(bs[i].innerText||'')+' '+(bs[i].getAttribute('aria-label')||'');if(/tools|도구/i.test(t)){bs[i].click();await sleep(900);b=findCanvas();break;}}}if(b){b.click();await sleep(900);return true;}return false;}
async function attach(inp,id){
 var n=Android.fileCount(id);
 if(!n)return;
 var dt=new DataTransfer();
 for(var i=0;i<n;i++){
  var f=JSON.parse(Android.getFile(id,i));
  var bin=atob(f.b64);var arr=new Uint8Array(bin.length);
  for(var j=0;j<bin.length;j++)arr[j]=bin.charCodeAt(j);
  dt.items.add(new File([arr],f.name,{type:f.mime}));
 }
 var fi=document.querySelector('input[type="file"]');
 if(fi){try{fi.files=dt.files;fi.dispatchEvent(new Event('change',{bubbles:true}));}catch(e){}}
 else{inp.focus();inp.dispatchEvent(new ClipboardEvent('paste',{clipboardData:dt,bubbles:true,cancelable:true}));}
 await sleep(4000+1500*n);
}
async function run(prompt,id,canvas){
 var inp=q(CFG.input);var w=0;
 while(!inp&&w<12000){await sleep(500);w+=500;inp=q(CFG.input);}
 if(!inp)return {error:'입력창을 찾지 못했어요 (로그인 필요? '+location.hostname+location.pathname+')'};
 var before=q(CFG.resp,true).length;var le=lastEl();var beforeTxt=le?textOf(le):'';
 if(canvas&&!window.__ghCanvasOn){try{if(await enableCanvas())window.__ghCanvasOn=true;}catch(e){}inp=q(CFG.input)||inp;}
 try{await attach(inp,id);}catch(e){}
 inp.focus();document.execCommand('selectAll');document.execCommand('insertText',false,prompt);
 await sleep(700);
 var btn=q(CFG.send);
 if(btn&&!btn.disabled)btn.click();else inp.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true}));
 await sleep(2500);
 if(!(q(CFG.resp,true).length>before||q(CFG.stop))){
  var rem=((inp.innerText||inp.value||'')+'').trim();
  if(rem){
   var b2=q(CFG.send);
   if(b2&&!b2.disabled)b2.click();
   else{var fm=inp.closest?inp.closest('form'):null;if(fm&&fm.requestSubmit)fm.requestSubmit();else inp.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true}));}
  }
 }
 function snap(){var rem=((inp.innerText||inp.value||'')+'').trim().length;return '입력창 남은글자 '+rem+', 전송버튼 '+(q(CFG.send)?'있음':'없음')+', 제목 '+document.title+', 화면끝: '+document.body.innerText.slice(-120).replace(/\s+/g,' ');}
 var start=Date.now(),last='',stable=0,sawResp=false;
 while(Date.now()-start<200000){
  await sleep(800);
  if(q(CFG.resp,true).length>before||q(CFG.stop))sawResp=true;
  if(!sawResp&&Date.now()-start>60000)return {error:'답변이 시작되지 않았어요 ('+snap()+')'};
  var el=lastEl();var txt=textOf(el);
  if(!txt||(q(CFG.resp,true).length<=before&&txt===beforeTxt))continue;
  var streaming=!!q(CFG.stop)||el.getAttribute('data-is-streaming')==='true';
  if(txt===last&&!streaming)stable++;else{stable=0;last=txt;}
  if(stable>=4)break;
 }
 if(canvas&&last){await sleep(1500);var cv=q(['code-immersive-panel','immersive-panel','[data-test-id*="canvas"]','[class*="immersive-editor"]']);if(cv&&cv.innerText.trim().length>20)last=last+'\n\n```\n'+cv.innerText.trim()+'\n```';}
 if(!last)return {error:'응답을 읽지 못했어요',limit:LIM.test(document.body.innerText.slice(-1500))};
 if(last.length<400&&LIM.test(last))return {error:'limit',limit:true};
 return {text:last};
}
window.__ghDiag=function(){return JSON.stringify({'입력창':!!q(CFG.input),'전송버튼':!!q(CFG.send),'캔버스버튼(보일때)':!!findCanvas(),'답변수':q(CFG.resp,true).length,'화면':document.visibilityState,'제목':document.title});};
window.__gh=function(id,prompt,canvas){run(prompt,id,!!canvas).then(function(r){Android.onResult(id,JSON.stringify(r));}).catch(function(e){Android.onResult(id,JSON.stringify({error:String(e)}));});};
})();
"""

private val EXT = mapOf(
    "js" to "js", "javascript" to "js", "html" to "html", "css" to "css", "json" to "json",
    "python" to "py", "py" to "py", "java" to "java", "kotlin" to "kt", "ts" to "ts",
    "typescript" to "ts", "md" to "md", "bash" to "sh", "sh" to "sh", "xml" to "xml", "sql" to "sql"
)

class Msg(val role: String, var who: String, var text: String)
class Att(val name: String, val mime: String, val bytes: ByteArray)

class Prov(val key: String, val label: String, val base: String, val cfg: String, val aliases: List<String>) {
    lateinit var web: WebView
}

class MainActivity : AppCompatActivity() {
    private val claude = Prov("claude", "Claude", "https://claude.ai/new", CLAUDE_CFG, listOf("claude", "클로드"))
    private val gemini = Prov("gemini", "Gemini", "https://gemini.google.com/app", GEMINI_CFG, listOf("gemini", "제미나이"))
    private val all = listOf(claude, gemini)

    private val scope = MainScope()
    private val handler = Handler(Looper.getMainLooper())
    private val pending = HashMap<String, (String) -> Unit>()
    private val msgs = ArrayList<Msg>()
    private val limited = HashMap<String, Boolean>()
    private val warned = HashMap<String, Boolean>()
    private val limitedAt = HashMap<String, Long>()
    private val lastLog = HashMap<String, String>()
    private var mode = 0
    private var rounds = 1
    private var gcanvas = false
    private var animPos = -1
    private var fadePos = -1
    private var busyAnim: ObjectAnimator? = null
    private var busy = false
    private var inFg = true
    private var job: Job? = null
    private var camUri: Uri? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val atts = ArrayList<Att>()
    private val reqFiles = ConcurrentHashMap<String, List<Att>>()
    private val prefs by lazy { getSharedPreferences("aihub", MODE_PRIVATE) }
    private var loginOpen = false
    private var loginProv: Prov? = null

    private lateinit var main: LinearLayout
    private lateinit var webHost: LinearLayout
    private lateinit var webFrame: FrameLayout
    private lateinit var loginBar: LinearLayout
    private lateinit var loginTitle: TextView
    private lateinit var rv: RecyclerView
    private lateinit var input: EditText
    private lateinit var chip: TextView
    private lateinit var sendBtn: TextView
    private lateinit var gchip: TextView
    private lateinit var statusBar: TextView
    private lateinit var rootLayout: FrameLayout
    private var previewView: View? = null
    private var previewWeb: WebView? = null
    private lateinit var tray: LinearLayout
    private lateinit var trayScroll: HorizontalScrollView

    private val pickImages = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris -> for (u in uris) addAtt(u) }
    private val pickFiles = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris -> for (u in uris) addAtt(u) }
    private val takePic = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val u = camUri
        if (ok && u != null) addAtt(u, "photo_" + System.currentTimeMillis() + ".jpg")
    }
    private val askNotif = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val modeNames = arrayOf("Claude", "Gemini", "모두 (각자 답)", "함께 만들기")
    private val modeChips = arrayOf("Claude ▾", "Gemini ▾", "모두 ▾", "함께 ▾")

    private val adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        override fun getItemCount() = msgs.size
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val c = LinearLayout(parent.context)
            c.orientation = LinearLayout.VERTICAL
            c.layoutParams = RecyclerView.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
            return object : RecyclerView.ViewHolder(c) {}
        }
        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            bind(holder.itemView as LinearLayout, msgs[position])
            val v = holder.itemView
            v.animate().cancel()
            v.alpha = 1f
            v.translationX = 0f
            v.translationY = 0f
            if (position == animPos) {
                animPos = -1
                v.alpha = 0f
                if (msgs[position].role == "user") v.translationX = dp(40).toFloat() else v.translationY = dp(24).toFloat()
                v.animate().alpha(1f).translationX(0f).translationY(0f).setDuration(300).start()
            } else if (position == fadePos) {
                fadePos = -1
                val ll = v as LinearLayout
                for (k in 0 until ll.childCount) {
                    val ch = ll.getChildAt(k)
                    ch.alpha = 0f
                    ch.translationY = dp(12).toFloat()
                    ch.animate().alpha(1f).translationY(0f).setStartDelay((k * 110).toLong()).setDuration(320).start()
                }
            }
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun onResult(id: String, json: String) {
            runOnUiThread { pending.remove(id)?.invoke(json); reqFiles.remove(id) }
        }

        @JavascriptInterface
        fun fileCount(id: String): Int = reqFiles[id]?.size ?: 0

        @JavascriptInterface
        fun getFile(id: String, i: Int): String {
            val a = reqFiles[id]?.get(i) ?: return ""
            val o = JSONObject()
            o.put("name", a.name)
            o.put("mime", a.mime)
            o.put("b64", Base64.encodeToString(a.bytes, Base64.NO_WRAP))
            return o.toString()
        }
    }

    // ------------------------------------------------------------ 화면
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadMsgs()
        buildUi()
        for (p in all) setupWeb(p)
        updateStatus()
        if (msgs.isEmpty()) addNote("안녕하세요! 먼저 ☰ 메뉴에서 Claude, Gemini에 로그인해 주세요.\n@claude, @gemini 로 시작하면 그 AI만 답해요.")
        handleShare(intent)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            askNotif.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShare(intent)
    }

    private fun handleShare(i: Intent?) {
        if (i == null || i.action != Intent.ACTION_SEND) return
        i.getStringExtra(Intent.EXTRA_TEXT)?.let { input.append(it) }
        @Suppress("DEPRECATION")
        val u = i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
        if (u != null) addAtt(u)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun lp(w: Int, h: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, h, wt)
    private fun bg(color: Int, r: Int, stroke: Int = 0, sc: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(r).toFloat()
        if (stroke > 0) g.setStroke(dp(stroke), sc)
        return g
    }
    private fun tv(t: String, size: Float, color: Int = INK): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        return v
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun copy(s: String) {
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("t", s))
        toast("복사했어요")
    }

    private fun pop(v: View) {
        v.animate().cancel()
        v.animate().scaleX(0.85f).scaleY(0.85f).setDuration(80).withEndAction {
            v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
        }.start()
    }

    private fun iconBtn(t: String, click: () -> Unit): TextView {
        val v = tv(t, 22f)
        v.gravity = Gravity.CENTER
        v.layoutParams = lp(dp(44), dp(44))
        v.setOnClickListener { pop(v); click() }
        return v
    }

    private fun buildUi() {
        val root = FrameLayout(this)
        rootLayout = root
        root.setBackgroundColor(BG)

        // 로그인용 웹뷰 영역 (평소엔 뒤에 숨어서 AI 사이트와 통신만 함)
        webHost = LinearLayout(this)
        webHost.orientation = LinearLayout.VERTICAL
        webHost.setBackgroundColor(Color.WHITE)
        webHost.alpha = 1f
        loginBar = LinearLayout(this)
        loginBar.orientation = LinearLayout.HORIZONTAL
        loginBar.gravity = Gravity.CENTER_VERTICAL
        loginBar.setBackgroundColor(BG)
        loginBar.setPadding(dp(16), 0, dp(8), 0)
        loginBar.visibility = View.GONE
        loginTitle = tv("로그인", 16f)
        loginTitle.typeface = Typeface.DEFAULT_BOLD
        val closeBtn = tv("완료", 15f, ORANGE)
        closeBtn.setPadding(dp(16), dp(10), dp(16), dp(10))
        closeBtn.setOnClickListener { closeLogin() }
        loginBar.addView(loginTitle, lp(0, WRAP_CONTENT, 1f))
        loginBar.addView(closeBtn, lp(WRAP_CONTENT, WRAP_CONTENT))
        webFrame = FrameLayout(this)
        webHost.addView(loginBar, lp(MATCH_PARENT, dp(52)))
        webHost.addView(webFrame, lp(MATCH_PARENT, 0, 1f))
        root.addView(webHost, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        // 메인 채팅 화면
        main = LinearLayout(this)
        main.orientation = LinearLayout.VERTICAL
        main.setBackgroundColor(BG)
        main.isClickable = true

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.setPadding(dp(8), dp(4), dp(8), dp(4))
        top.addView(iconBtn("☰") { menu() })
        val title = tv("AI 허브", 20f)
        title.typeface = Typeface.SERIF
        title.gravity = Gravity.CENTER
        top.addView(title, lp(0, WRAP_CONTENT, 1f))
        title.alpha = 0f
        title.translationY = -dp(10).toFloat()
        title.animate().alpha(1f).translationY(0f).setStartDelay(100).setDuration(500).start()
        top.addView(iconBtn("✎") { newChat() })
        main.addView(top, lp(MATCH_PARENT, WRAP_CONTENT))
        statusBar = tv("", 12f, 0xFFB45309.toInt())
        statusBar.gravity = Gravity.CENTER
        statusBar.setPadding(dp(12), dp(4), dp(12), dp(8))
        statusBar.visibility = View.GONE
        main.addView(statusBar, lp(MATCH_PARENT, WRAP_CONTENT))

        rv = RecyclerView(this)
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = adapter
        rv.itemAnimator = null
        rv.clipToPadding = false
        rv.setPadding(dp(16), dp(8), dp(16), dp(8))
        main.addView(rv, lp(MATCH_PARENT, 0, 1f))

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = bg(Color.WHITE, 24, 1, LINE)
        card.setPadding(dp(16), dp(10), dp(10), dp(10))
        card.elevation = dp(2).toFloat()
        trayScroll = HorizontalScrollView(this)
        trayScroll.isHorizontalScrollBarEnabled = false
        trayScroll.visibility = View.GONE
        tray = LinearLayout(this)
        tray.orientation = LinearLayout.HORIZONTAL
        trayScroll.addView(tray)
        card.addView(trayScroll, lp(MATCH_PARENT, WRAP_CONTENT))
        input = EditText(this)
        input.hint = "무엇이든 물어보세요  (@claude @gemini)"
        input.setHintTextColor(SUB)
        input.setTextColor(INK)
        input.background = null
        input.textSize = 16f
        input.maxLines = 5
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        card.addView(input, lp(MATCH_PARENT, WRAP_CONTENT))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val plus = tv("+", 22f)
        plus.gravity = Gravity.CENTER
        plus.background = bg(Color.WHITE, 20, 1, LINE)
        plus.setOnClickListener { pop(plus); attachMenu() }
        row.addView(plus, lp(dp(40), dp(40)))
        chip = tv(modeChips[mode], 14f)
        chip.background = bg(USERBG, 20)
        chip.setPadding(dp(16), dp(9), dp(16), dp(9))
        chip.setOnClickListener { pop(chip); modeMenu() }
        val cl = lp(WRAP_CONTENT, WRAP_CONTENT)
        cl.leftMargin = dp(8)
        row.addView(chip, cl)
        gchip = tv("", 14f)
        gchip.background = bg(USERBG, 20)
        gchip.setPadding(dp(14), dp(9), dp(14), dp(9))
        gchip.setOnClickListener { pop(gchip); geminiModeMenu() }
        val gl = lp(WRAP_CONTENT, WRAP_CONTENT)
        gl.leftMargin = dp(6)
        row.addView(gchip, gl)
        updateChips()
        row.addView(View(this), lp(0, 1, 1f))
        sendBtn = tv("↑", 22f, Color.WHITE)
        sendBtn.gravity = Gravity.CENTER
        sendBtn.typeface = Typeface.DEFAULT_BOLD
        sendBtn.background = bg(ORANGE, 20)
        sendBtn.setOnClickListener { pop(sendBtn); send() }
        row.addView(sendBtn, lp(dp(40), dp(40)))
        card.addView(row, lp(MATCH_PARENT, WRAP_CONTENT))
        val cardLp = lp(MATCH_PARENT, WRAP_CONTENT)
        cardLp.setMargins(dp(12), dp(4), dp(12), dp(12))
        main.addView(card, cardLp)
        card.alpha = 0f
        card.translationY = dp(80).toFloat()
        card.animate().alpha(1f).translationY(0f).setDuration(450).setStartDelay(150).start()

        root.addView(main, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        setContentView(root)
    }

    // ------------------------------------------------------------ 메시지 표시
    private fun addMsg(m: Msg) {
        msgs.add(m)
        animPos = msgs.size - 1
        adapter.notifyItemInserted(msgs.size - 1)
        rv.post { rv.scrollToPosition(msgs.size - 1) }
        saveMsgs()
    }
    private fun addNote(t: String) = addMsg(Msg("note", "", t))
    private fun refresh(m: Msg) {
        val i = msgs.indexOf(m)
        if (i >= 0) {
            fadePos = i
            adapter.notifyItemChanged(i)
        }
        rv.post { rv.scrollToPosition(msgs.size - 1) }
        saveMsgs()
    }

    private fun saveMsgs() {
        val a = JSONArray()
        for (m in msgs.takeLast(200)) {
            if (m.role == "ai" && m.text == "생각 중…") continue
            val o = JSONObject()
            o.put("r", m.role)
            o.put("w", m.who)
            o.put("t", m.text)
            a.put(o)
        }
        prefs.edit().putString("msgs", a.toString()).putInt("mode2", mode).putInt("rounds", rounds).putBoolean("gcanvas", gcanvas).apply()
    }

    private fun loadMsgs() {
        mode = prefs.getInt("mode2", 0)
        if (mode < 0 || mode > 3) mode = 0
        rounds = prefs.getInt("rounds", 1)
        gcanvas = prefs.getBoolean("gcanvas", false)
        try {
            val a = JSONArray(prefs.getString("msgs", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                msgs.add(Msg(o.getString("r"), o.getString("w"), o.getString("t")))
            }
        } catch (e: Exception) {
        }
    }

    private fun bind(c: LinearLayout, m: Msg) {
        c.removeAllViews()
        when (m.role) {
            "user" -> {
                val t = tv(m.text, 16f)
                t.background = bg(USERBG, 18)
                t.setPadding(dp(14), dp(10), dp(14), dp(10))
                t.setTextIsSelectable(true)
                val l = lp(WRAP_CONTENT, WRAP_CONTENT)
                l.gravity = Gravity.END
                l.leftMargin = dp(48)
                l.topMargin = dp(10)
                c.addView(t, l)
            }
            "note" -> {
                val t = tv(m.text, 13f, SUB)
                t.gravity = Gravity.CENTER
                val l = lp(MATCH_PARENT, WRAP_CONTENT)
                l.topMargin = dp(12)
                c.addView(t, l)
            }
            else -> {
                val who = tv(m.who, 13f, ORANGE)
                who.typeface = Typeface.DEFAULT_BOLD
                val wl = lp(WRAP_CONTENT, WRAP_CONTENT)
                wl.topMargin = dp(14)
                c.addView(who, wl)
                if (m.text == "생각 중…") addDots(c) else renderRich(c, m.text)
                if (m.text != "생각 중…") {
                    val a = tv("복사", 13f, SUB)
                    a.setPadding(0, dp(8), dp(12), dp(4))
                    a.setOnClickListener { copy(m.text) }
                    c.addView(a, lp(WRAP_CONTENT, WRAP_CONTENT))
                }
            }
        }
    }

    private fun addDots(c: LinearLayout) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(0, dp(8), 0, dp(8))
        for (i in 0 until 3) {
            val d = tv("●", 12f, ORANGE)
            d.setPadding(0, 0, dp(6), 0)
            row.addView(d)
            val a = ObjectAnimator.ofFloat(d, "translationY", 0f, -dp(6).toFloat(), 0f)
            a.duration = 700
            a.startDelay = (i * 160).toLong()
            a.repeatCount = ValueAnimator.INFINITE
            a.start()
            d.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
                override fun onViewAttachedToWindow(v: View) {}
                override fun onViewDetachedFromWindow(v: View) {
                    a.cancel()
                }
            })
        }
        c.addView(row, lp(WRAP_CONTENT, WRAP_CONTENT))
    }

    private fun md(s: String): String {
        var h = TextUtils.htmlEncode(s.trim())
        h = h.replace(Regex("(?m)^#{1,3} (.*)$"), "<b>$1</b>")
        h = h.replace(Regex("\\*\\*(.+?)\\*\\*"), "<b>$1</b>")
        h = h.replace(Regex("`([^`\\n]+)`"), "<tt>$1</tt>")
        return h.replace("\n", "<br>")
    }

    private fun addText(c: LinearLayout, s: String) {
        if (s.isBlank()) return
        val t = tv("", 16f)
        t.text = Html.fromHtml(md(s), Html.FROM_HTML_MODE_COMPACT)
        t.setLineSpacing(0f, 1.15f)
        t.setTextIsSelectable(true)
        val l = lp(MATCH_PARENT, WRAP_CONTENT)
        l.topMargin = dp(4)
        c.addView(t, l)
    }

    private fun renderRich(c: LinearLayout, text: String) {
        val re = Regex("```(\\w*)\\n([\\s\\S]*?)```")
        var last = 0
        var n = 0
        for (m in re.findAll(text)) {
            addText(c, text.substring(last, m.range.first))
            last = m.range.last + 1
            n++
            val ext = EXT[m.groupValues[1].lowercase()] ?: "txt"
            addCodeCard(c, "result$n.$ext", m.groupValues[2].trim('\n'))
        }
        addText(c, text.substring(last))
    }

    // 파일 카드
    private fun addCodeCard(c: LinearLayout, name: String, code: String) {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = bg(CARD, 12, 1, LINE)
        val nm = tv("📄 $name", 14f)
        nm.typeface = Typeface.DEFAULT_BOLD
        nm.maxLines = 1
        nm.ellipsize = TextUtils.TruncateAt.END
        nm.setPadding(dp(12), dp(8), dp(12), 0)
        card.addView(nm, lp(MATCH_PARENT, WRAP_CONTENT))
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setPadding(dp(4), dp(2), dp(4), dp(2))
        fun btn(t: String, f: () -> Unit) {
            val b = tv(t, 13f, ORANGE)
            b.setPadding(dp(10), dp(6), dp(10), dp(6))
            b.setOnClickListener { f() }
            bar.addView(b, lp(WRAP_CONTENT, WRAP_CONTENT))
        }
        if (name.endsWith(".html")) btn("▶ 미리보기") { showPreview(name, code) }
        btn("게시") { publishGist(name, code) }
        btn("복사") { copy(code) }
        btn("공유") {
            val i = Intent(Intent.ACTION_SEND)
            i.type = "text/plain"
            i.putExtra(Intent.EXTRA_TEXT, code)
            i.putExtra(Intent.EXTRA_SUBJECT, name)
            startActivity(Intent.createChooser(i, name))
        }
        card.addView(bar, lp(MATCH_PARENT, WRAP_CONTENT))
        val body = tv(code, 12f)
        body.typeface = Typeface.MONOSPACE
        body.setPadding(dp(12), dp(4), dp(12), dp(10))
        body.maxLines = 10
        body.ellipsize = TextUtils.TruncateAt.END
        body.setOnClickListener { body.maxLines = if (body.maxLines == 10) 1000 else 10 }
        card.addView(body, lp(MATCH_PARENT, WRAP_CONTENT))
        val l = lp(MATCH_PARENT, WRAP_CONTENT)
        l.topMargin = dp(8)
        l.bottomMargin = dp(4)
        c.addView(card, l)
    }

    // ------------------------------------------------------------ 메뉴
    private fun menu() {
        val items = arrayOf(
            "🔑 Claude 로그인", "🔑 Gemini 로그인",
            "✨ Gemini 모드: " + (if (gcanvas) "Canvas" else "일반") + " (누르면 선택)",
            "🩺 연결 점검", "📤 대화 내보내기", "🔋 백그라운드 설정",
            "🗑 새 대화", "🔁 다듬기 단계: $rounds (누르면 변경)", "ℹ️ 사용법"
        )
        AlertDialog.Builder(this).setItems(items) { _, w ->
            when (w) {
                0 -> openLogin(claude)
                1 -> openLogin(gemini)
                2 -> geminiModeMenu()
                3 -> diagnose()
                4 -> exportChat()
                5 -> try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (e: Exception) { toast("설정 > 앱 > AI 허브 > 배터리 > 제한 없음 으로 바꿔주세요") }
                6 -> newChat()
                7 -> { rounds = rounds % 3 + 1; saveMsgs(); toast("다듬기 단계: $rounds") }
                8 -> AlertDialog.Builder(this).setMessage(
                    "1. ☰ → 로그인에서 Claude, Gemini에 로그인하고 '완료'를 눌러요.\n" +
                    "2. 아래 칩에서 AI를 고르거나, 메시지 앞에 @claude / @gemini 를 붙이면 그 AI만 답해요.\n" +
                    "3. Gemini는 '일반' 또는 'Canvas' 모드를 고를 수 있어요. 모드를 바꾸면 Gemini가 새 대화로 시작돼요.\n" +
                    "4. '함께 만들기'를 고르면 AI들이 따로 답하지 않고, 하나의 결과물을 번갈아 직접 고치며 함께 만들어요. '다듬기 단계'만큼 보완이 이어져요.\n" +
                    "5. + 버튼으로 카메라, 사진, 파일을 보낼 수 있어요. 다른 앱에서 '공유'로 보내도 돼요.\n" +
                    "6. 답을 기다리는 중에 앱을 나가도 계속 일하고, 끝나면 알림이 와요. 전송 버튼이 ■ 이면 누르면 중단돼요.\n" +
                    "7. 답이 안 오면 🩺 연결 점검을 눌러 결과를 알려주세요."
                ).setPositiveButton("확인", null).show()
            }
        }.show()
    }

    private fun attachMenu() {
        val items = arrayOf("📷 카메라로 찍기", "🖼 사진 선택", "📎 파일 선택")
        AlertDialog.Builder(this).setItems(items) { _, w ->
            when (w) {
                0 -> {
                    val f = File(cacheDir, "cam_" + System.currentTimeMillis() + ".jpg")
                    val u = FileProvider.getUriForFile(this, packageName + ".fileprovider", f)
                    camUri = u
                    takePic.launch(u)
                }
                1 -> pickImages.launch("image/*")
                2 -> pickFiles.launch("*/*")
            }
        }.show()
    }

    private fun addAtt(uri: Uri, forcedName: String? = null) {
        try {
            var name = forcedName ?: "file"
            if (forcedName == null) {
                contentResolver.query(uri, null, null, null, null)?.use { c ->
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0 && c.moveToFirst()) name = c.getString(i) ?: name
                }
            }
            var mime = contentResolver.getType(uri) ?: (if (forcedName != null) "image/jpeg" else "application/octet-stream")
            var bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return
            if (mime.startsWith("image/") && mime != "image/gif") {
                val small = shrink(bytes)
                if (small != null) {
                    bytes = small
                    mime = "image/jpeg"
                    val low = name.lowercase()
                    if (!low.endsWith(".jpg") && !low.endsWith(".jpeg")) name = name.substringBeforeLast('.') + ".jpg"
                }
            }
            if (atts.sumOf { it.bytes.size } + bytes.size > 12000000) {
                toast("첨부는 합쳐서 12MB까지 가능해요")
                return
            }
            atts.add(Att(name, mime, bytes))
            renderTray()
        } catch (e: Exception) {
            toast("첨부하지 못했어요")
        }
    }

    private fun shrink(src: ByteArray): ByteArray? {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeByteArray(src, 0, src.size, o)
        if (o.outWidth <= 0) return null
        var s = 1
        while (o.outWidth / s > 1800 || o.outHeight / s > 1800) s *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = s
        val bmp = BitmapFactory.decodeByteArray(src, 0, src.size, o2) ?: return null
        val rot = try {
            when (android.media.ExifInterface(ByteArrayInputStream(src)).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1)) {
                6 -> 90f
                3 -> 180f
                8 -> 270f
                else -> 0f
            }
        } catch (e: Exception) {
            0f
        }
        val fin = if (rot != 0f) {
            val m = android.graphics.Matrix()
            m.postRotate(rot)
            Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        } else bmp
        val out = ByteArrayOutputStream()
        fin.compress(Bitmap.CompressFormat.JPEG, 85, out)
        return out.toByteArray()
    }

    private fun renderTray() {
        tray.removeAllViews()
        trayScroll.visibility = if (atts.isEmpty()) View.GONE else View.VISIBLE
        for (a in atts.toList()) {
            val t = tv((if (a.mime.startsWith("image/")) "🖼 " else "📎 ") + a.name.take(18) + "  ✕", 13f)
            t.background = bg(USERBG, 14)
            t.setPadding(dp(12), dp(6), dp(12), dp(6))
            t.setOnClickListener {
                atts.remove(a)
                renderTray()
            }
            val l = lp(WRAP_CONTENT, WRAP_CONTENT)
            l.rightMargin = dp(6)
            l.bottomMargin = dp(6)
            tray.addView(t, l)
            t.alpha = 0f
            t.scaleX = 0.8f
            t.scaleY = 0.8f
            t.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(200).start()
        }
    }

    private fun exportChat() {
        val sb = StringBuilder()
        for (m in msgs) if (m.role != "note") sb.append("[").append(m.who).append("]\n").append(m.text).append("\n\n")
        if (sb.isEmpty()) {
            toast("내보낼 대화가 없어요")
            return
        }
        val i = Intent(Intent.ACTION_SEND)
        i.type = "text/plain"
        i.putExtra(Intent.EXTRA_TEXT, sb.toString())
        startActivity(Intent.createChooser(i, "대화 내보내기"))
    }

    private fun diagnose() {
        val res = ArrayList<String>()
        for (p in all) {
            p.web.evaluateJavascript(WORKER_JS.replace("%CFG%", p.cfg)) {
                p.web.evaluateJavascript("window.__ghDiag ? window.__ghDiag() : 'worker 없음 (페이지 로딩 안 됨?)'") { r ->
                    val s = try { (JSONTokener(r).nextValue() as? String) ?: r } catch (e: Exception) { r }
                    res.add(p.label + ": " + s + "\n주소: " + (p.web.url ?: "없음") + "\n마지막 응답: " + (lastLog[p.key] ?: "아직 없음") + "\n한도 표시: " + (if (isLimited(p.key)) "켜짐" else "꺼짐"))
                    if (res.size == all.size) {
                        AlertDialog.Builder(this).setTitle("연결 점검 (빌드 11-25b)").setMessage(res.joinToString("\n\n")).setPositiveButton("확인", null).show()
                    }
                }
            }
        }
    }

    private fun updateStatus() {
        val lim = all.filter { isLimited(it.key) }
        if (lim.isEmpty()) {
            statusBar.visibility = View.GONE
        } else {
            statusBar.text = "⚠️ " + lim.joinToString(", ") { it.label } + " 사용량 한도에 도달 · 10분 뒤 자동으로 다시 시도해요"
            statusBar.visibility = View.VISIBLE
        }
        updateChips()
    }

    private fun updateChips() {
        val warn = when (mode) {
            0 -> isLimited("claude")
            1 -> isLimited("gemini")
            else -> all.any { isLimited(it.key) }
        }
        chip.text = modeChips[mode] + (if (warn) " ⚠" else "")
        gchip.text = "Gemini: " + (if (gcanvas) "Canvas" else "일반") + " ▾"
        gchip.visibility = if (mode >= 1) View.VISIBLE else View.GONE
    }

    private fun geminiModeMenu() {
        AlertDialog.Builder(this).setTitle("Gemini 모드").setItems(arrayOf("일반 모드", "Canvas 모드")) { _, w ->
            val cv = (w == 1)
            if (cv != gcanvas) {
                gcanvas = cv
                saveMsgs()
                gemini.web.loadUrl(gemini.base)
                toast("Gemini를 새 대화로 시작해요")
            }
            updateChips()
        }.show()
    }

    private fun modeMenu() {
        AlertDialog.Builder(this).setItems(modeNames) { _, w ->
            mode = w
            updateChips()
            saveMsgs()
        }.show()
    }
    private fun newChat() {
        msgs.clear()
        adapter.notifyDataSetChanged()
        limited.clear()
        warned.clear()
        updateStatus()
        for (p in all) p.web.loadUrl(p.base)
        saveMsgs()
        addNote("새 대화를 시작했어요.")
    }

    // ------------------------------------------------------------ 웹뷰(각 AI 사이트)
    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWeb(p: Prov) {
        val w = WebView(this)
        p.web = w
        val st = w.settings
        st.javaScriptEnabled = true
        st.domStorageEnabled = true
        st.userAgentString = st.userAgentString.replace("; wv", "").replace(Regex("Version/\\d+\\.\\d+ "), "")
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)
        w.addJavascriptInterface(Bridge(), "Android")
        w.webChromeClient = WebChromeClient()
        w.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String?) {
                view.evaluateJavascript(WORKER_JS.replace("%CFG%", p.cfg), null)
                CookieManager.getInstance().flush()
            }
        }
        webFrame.addView(w, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        w.loadUrl(p.base)
    }

    private fun openLogin(p: Prov) {
        loginProv = p
        loginTitle.text = p.label + " 로그인"
        loginBar.visibility = View.VISIBLE
        for (o in all) o.web.visibility = if (o === p) View.VISIBLE else View.INVISIBLE
        webHost.alpha = 1f
        webHost.bringToFront()
        webHost.translationY = webHost.height.toFloat()
        webHost.animate().translationY(0f).setDuration(280).start()
        loginOpen = true
    }
    private fun closeLogin() {
        loginOpen = false
        val done = Runnable {
            loginBar.visibility = View.GONE
            for (o in all) o.web.visibility = View.VISIBLE
            main.bringToFront()
            webHost.translationY = 0f
            loginProv?.let { it.web.loadUrl(it.base) }
        }
        webHost.animate().translationY(webHost.height.toFloat()).setDuration(220).withEndAction(done).start()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (previewView != null) {
            closePreview()
            return
        }
        val p = loginProv
        if (loginOpen && p != null) {
            if (p.web.canGoBack()) p.web.goBack() else closeLogin()
        } else {
            @Suppress("DEPRECATION")
            super.onBackPressed()
        }
    }

    override fun onStart() {
        super.onStart()
        inFg = true
    }

    override fun onStop() {
        super.onStop()
        inFg = false
        for (p in all) p.web.resumeTimers()
        CookieManager.getInstance().flush()
        saveMsgs()
    }
    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    // ------------------------------------------------------------ AI 호출
    private suspend fun raw(p: Prov, prompt: String, files: List<Att> = emptyList(), canvas: Boolean = false): JSONObject = suspendCancellableCoroutine { cont ->
        val id = UUID.randomUUID().toString()
        if (files.isNotEmpty()) reqFiles[id] = files
        val timeout = Runnable {
            reqFiles.remove(id)
            if (pending.remove(id) != null && cont.isActive) cont.resume(JSONObject("{\"error\":\"시간 초과\"}"))
        }
        pending[id] = { json ->
            handler.removeCallbacks(timeout)
            if (cont.isActive) cont.resume(JSONObject(json))
        }
        handler.postDelayed(timeout, 240000)
        cont.invokeOnCancellation {
            pending.remove(id)
            reqFiles.remove(id)
            handler.removeCallbacks(timeout)
        }
        p.web.evaluateJavascript(WORKER_JS.replace("%CFG%", p.cfg)) {
            p.web.evaluateJavascript("typeof window.__gh") { r ->
                if (r != "\"function\"") {
                    pending.remove(id)
                    reqFiles.remove(id)
                    handler.removeCallbacks(timeout)
                    if (cont.isActive) cont.resume(JSONObject("{\"error\":\"페이지가 아직 준비되지 않았어요. 잠시 후 다시 시도하세요\"}"))
                } else {
                    p.web.evaluateJavascript("window.__gh(" + JSONObject.quote(id) + "," + JSONObject.quote(prompt) + "," + canvas + ")", null)
                }
            }
        }
    }

    private fun isLimited(key: String): Boolean {
        if (limited[key] != true) return false
        if (System.currentTimeMillis() - (limitedAt[key] ?: 0L) > 10 * 60 * 1000L) {
            limited[key] = false
            warned[key] = false
            return false
        }
        return true
    }

    private suspend fun askQuiet(p: Prov, prompt: String, files: List<Att> = emptyList(), canvas: Boolean = false): String? {
        if (isLimited(p.key)) return null
        val r = raw(p, prompt, files, canvas)
        lastLog[p.key] = r.toString().take(300)
        val text = r.optString("text", "")
        if (text.isNotEmpty()) return text
        if (r.optBoolean("limit")) {
            limited[p.key] = true
            limitedAt[p.key] = System.currentTimeMillis()
            handler.postDelayed({ updateStatus() }, 10 * 60 * 1000L + 1000L)
            if (warned[p.key] != true) {
                warned[p.key] = true
                addNote("⚠️ " + p.label + " 사용량 한도에 도달했습니다")
            }
            updateStatus()
            return null
        }
        val err = r.optString("error", "응답 없음")
        addNote("⚠️ " + p.label + ": " + err + (if (err.contains("입력창")) "  (☰ → 로그인에서 로그인하세요)" else ""))
        return null
    }

    private suspend fun askInto(p: Prov, prompt: String, files: List<Att> = emptyList(), canvas: Boolean = false): String? {
        if (isLimited(p.key)) return null
        val m = Msg("ai", p.label, "생각 중…")
        addMsg(m)
        val t = askQuiet(p, prompt, files, canvas)
        if (t != null) {
            m.text = t
            refresh(m)
            return t
        }
        val i = msgs.indexOf(m)
        if (i >= 0) {
            msgs.removeAt(i)
            adapter.notifyItemRemoved(i)
        }
        return null
    }

    private fun send() {
        if (busy) {
            job?.cancel()
            return
        }
        val t = input.text.toString().trim()
        if (t.isEmpty() && atts.isEmpty()) return
        val files = atts.toList()
        atts.clear()
        renderTray()
        input.setText("")
        val label = if (files.isNotEmpty()) "\n" + files.joinToString("  ") { "📎" + it.name } else ""
        addMsg(Msg("user", "나", t + label))
        setBusy(true)
        job = scope.launch {
            var done = false
            try {
                runAI(if (t.isEmpty()) "첨부한 파일을 확인해 줘" else t, files)
                done = true
            } finally {
                val before = msgs.size
                msgs.removeAll { it.role == "ai" && it.text == "생각 중…" }
                if (msgs.size != before) adapter.notifyDataSetChanged()
                setBusy(false, done)
            }
        }
    }

    // 답변을 기다리는 동안 앱이 백그라운드로 가도 계속 일하게 붙잡기
    private fun setBusy(b: Boolean, notify: Boolean = false) {
        busy = b
        sendBtn.text = if (b) "■" else "↑"
        busyAnim?.cancel()
        busyAnim = null
        sendBtn.alpha = 1f
        if (b) {
            val a = ObjectAnimator.ofFloat(sendBtn, "alpha", 1f, 0.45f)
            a.duration = 600
            a.repeatMode = ValueAnimator.REVERSE
            a.repeatCount = ValueAnimator.INFINITE
            a.start()
            busyAnim = a
        }
        if (b) {
            try {
                ContextCompat.startForegroundService(this, Intent(this, WorkService::class.java))
            } catch (e: Exception) {
            }
            try {
                val pm = getSystemService(POWER_SERVICE) as PowerManager
                val wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "aihub:work")
                wl.acquire(15 * 60 * 1000L)
                wakeLock = wl
            } catch (e: Exception) {
            }
        } else {
            try {
                stopService(Intent(this, WorkService::class.java))
            } catch (e: Exception) {
            }
            try {
                wakeLock?.let { if (it.isHeld) it.release() }
            } catch (e: Exception) {
            }
            wakeLock = null
            if (notify && !inFg) notifyDone()
        }
    }

    private fun notifyDone() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("done", "답변 도착", NotificationManager.IMPORTANCE_DEFAULT))
        val pi = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "done")
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle("AI 허브")
            .setContentText("답변이 도착했어요")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(2, n)
    }

    private suspend fun runAI(rawText: String, files: List<Att> = emptyList()) {
        val found = ArrayList<Prov>()
        val prompt = Regex("@([A-Za-z가-힣]+)").replace(rawText) { mr ->
            val w = mr.groupValues[1].lowercase()
            val p = all.find { w in it.aliases }
            if (p != null) {
                if (!found.contains(p)) found.add(p)
                ""
            } else mr.value
        }.trim()
        if (prompt.isEmpty()) {
            addNote("요청 내용을 같이 적어주세요")
            return
        }
        var active: List<Prov> = if (found.isNotEmpty()) found.toList() else when (mode) {
            0 -> listOf(claude)
            1 -> listOf(gemini)
            else -> all
        }
        active = active.filter { !isLimited(it.key) }
        if (active.isEmpty()) {
            addNote("사용할 수 있는 AI가 없어요 (사용량 한도 도달)")
            return
        }
        if (mode == 3 && active.size >= 2) {
            coCreate(prompt, active, files)
            return
        }
        coroutineScope {
            active.map { p -> async { askInto(p, prompt, files, p === gemini && gcanvas) } }.awaitAll()
        }
    }

    // [변경] 한 줄 요약 / --- / 결과물 전체 형식을 나눠 읽기
    private fun splitWork(t: String): Pair<String, String> {
        val lines = t.trim().split("\n")
        if (lines.isNotEmpty() && lines[0].trim().startsWith("[변경]")) {
            val sum = lines[0].trim().removePrefix("[변경]").trim()
            var rest = lines.drop(1)
            val sep = rest.indexOfFirst { it.trim() == "---" }
            if (sep in 0..2) rest = rest.drop(sep + 1)
            return Pair(sum, rest.joinToString("\n").trim())
        }
        return Pair("", t.trim())
    }

    // 따로 답하지 않고, 하나의 결과물을 AI들이 번갈아 직접 고치며 함께 만들기
    private suspend fun coCreate(prompt: String, ais: List<Prov>, files: List<Att>) {
        val team = ais.toMutableList()
        val names = ais.joinToString(" + ") { it.label }
        addNote("🤝 " + ais.joinToString(" → ") { it.label } + " 순서로 하나의 결과물을 이어서 함께 만들어요")
        val shared = Msg("ai", names + " 함께", "생각 중…")
        addMsg(shared)
        val total = rounds + 1
        val sentFiles = HashSet<String>()
        val who = ArrayList<String>()
        var draft = ""
        var turn = 0
        var idx = 0
        while (turn < total && team.isNotEmpty()) {
            if (turn >= 1 && team.size < 2) break
            val p = team[idx % team.size]
            val last = (turn == total - 1)
            val q = if (draft.isEmpty()) {
                "너는 " + names + " 팀의 초안 담당이야. 다른 AI가 이어서 이 결과물을 함께 고쳐 나갈 거야.\n\n요청: " + prompt +
                    "\n\n요청에 맞는 결과물을 처음부터 끝까지 완성도 있게 만들어줘. 코드나 파일이 필요하면 완성된 코드 블록으로 줘." +
                    "\n\n답변 형식: 첫 줄은 '[변경] 초안 작성', 둘째 줄은 '---', 그 아래에 전체 결과물."
            } else {
                "원래 요청: " + prompt + "\n\n지금까지 팀(" + who.joinToString(", ") + ")이 함께 만든 현재 결과물:\n" + draft +
                    "\n\n너는 이어서 함께 만드는 팀원이야. 의견만 말하지 말고 현재 결과물을 직접 고쳐서 더 낫게 만들어줘(빠진 부분 추가, 오류 수정, 구조 개선). 좋은 부분은 그대로 살려줘." +
                    (if (last) " 이번이 마지막 단계니까 바로 쓸 수 있는 완성본으로 마무리해줘." else "") +
                    "\n\n답변 형식: 첫 줄은 '[변경] 무엇을 바꿨는지 한 줄', 둘째 줄은 '---', 그 아래에 수정이 반영된 결과물 전체."
            }
            val t = askQuiet(p, q, if (sentFiles.add(p.key)) files else emptyList(), false)
            if (t == null) {
                team.remove(p)
                continue
            }
            val parts = splitWork(t)
            draft = if (parts.second.isEmpty()) t.trim() else parts.second
            who.add(p.label)
            shared.text = draft
            refresh(shared)
            addNote("🤝 " + p.label + (if (turn == 0) " 초안: " else " 보완: ") + (if (parts.first.isEmpty()) "이어서 다듬었어요" else parts.first))
            turn++
            idx++
        }
        if (draft.isEmpty()) {
            val i = msgs.indexOf(shared)
            if (i >= 0) {
                msgs.removeAt(i)
                adapter.notifyItemRemoved(i)
            }
            addNote("함께 만들지 못했어요")
            return
        }
        shared.who = who.distinct().joinToString(" + ") + " · 함께 만든 완성본"
        refresh(shared)
        addNote("✨ 함께 만든 완성본이에요")
    }

    // ------------------------------------------------------------ 미리보기 / 게시
    @SuppressLint("SetJavaScriptEnabled")
    private fun showPreview(name: String, html: String) {
        closePreview()
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setBackgroundColor(Color.WHITE)
        box.isClickable = true
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(BG)
        bar.setPadding(dp(16), 0, dp(8), 0)
        val title = tv("▶ " + name, 15f)
        title.typeface = Typeface.DEFAULT_BOLD
        title.maxLines = 1
        val close = tv("닫기", 15f, ORANGE)
        close.setPadding(dp(16), dp(10), dp(16), dp(10))
        close.setOnClickListener { closePreview() }
        bar.addView(title, lp(0, WRAP_CONTENT, 1f))
        bar.addView(close, lp(WRAP_CONTENT, WRAP_CONTENT))
        val w = WebView(this)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.webViewClient = WebViewClient()
        w.loadDataWithBaseURL("https://preview.aihub.local/", html, "text/html", "utf-8", null)
        box.addView(bar, lp(MATCH_PARENT, dp(52)))
        box.addView(w, lp(MATCH_PARENT, 0, 1f))
        rootLayout.addView(box, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        box.alpha = 0f
        box.animate().alpha(1f).setDuration(200).start()
        previewView = box
        previewWeb = w
    }

    private fun closePreview() {
        previewView?.let { rootLayout.removeView(it) }
        previewWeb?.destroy()
        previewView = null
        previewWeb = null
    }

    private fun askToken(then: () -> Unit) {
        val et = EditText(this)
        et.hint = "ghp_..."
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        AlertDialog.Builder(this)
            .setTitle("GitHub 토큰")
            .setMessage("게시하려면 GitHub 토큰(gist 권한)이 필요해요. 이 폰에만 저장돼요.\ngithub.com/settings/tokens 에서 만들 수 있어요.")
            .setView(et)
            .setPositiveButton("저장") { _, _ ->
                val t = et.text.toString().trim()
                if (t.isNotEmpty()) {
                    prefs.edit().putString("ghtoken", t).apply()
                    then()
                }
            }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun publishGist(name: String, code: String) {
        val tok = prefs.getString("ghtoken", "") ?: ""
        if (tok.isEmpty()) {
            askToken { publishGist(name, code) }
            return
        }
        toast("게시하는 중…")
        scope.launch {
            val res = withContext(Dispatchers.IO) {
                try {
                    postGist(tok, name, code)
                } catch (e: Exception) {
                    "ERR:" + (e.message ?: "실패")
                }
            }
            showPublished(res, name)
        }
    }

    private fun postGist(tok: String, name: String, code: String): String {
        val files = JSONObject()
        files.put(name, JSONObject().put("content", code))
        val body = JSONObject()
        body.put("public", false)
        body.put("description", "AI 허브에서 게시")
        body.put("files", files)
        val conn = java.net.URL("https://api.github.com/gists").openConnection() as java.net.HttpURLConnection
        conn.requestMethod = "POST"
        conn.doOutput = true
        conn.connectTimeout = 15000
        conn.readTimeout = 20000
        conn.setRequestProperty("Authorization", "Bearer " + tok)
        conn.setRequestProperty("Accept", "application/vnd.github+json")
        conn.setRequestProperty("Content-Type", "application/json")
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        val status = conn.responseCode
        val stream = if (status in 200..299) conn.inputStream else conn.errorStream
        val txt = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (status !in 200..299) {
            val msg = try { JSONObject(txt).optString("message") } catch (e: Exception) { txt.take(100) }
            return "ERR:" + status + " " + msg
        }
        val j = JSONObject(txt)
        val owner = j.optJSONObject("owner")?.optString("login") ?: ""
        return j.optString("html_url") + "|" + owner + "|" + j.optString("id")
    }

    private fun showPublished(res: String, name: String) {
        if (res.startsWith("ERR:")) {
            AlertDialog.Builder(this)
                .setTitle("게시하지 못했어요")
                .setMessage(res.substring(4))
                .setPositiveButton("확인", null)
                .setNeutralButton("토큰 다시 입력") { _, _ ->
                    prefs.edit().remove("ghtoken").apply()
                    askToken { toast("저장했어요. 다시 게시를 눌러주세요") }
                }
                .show()
            return
        }
        val parts = res.split("|")
        val url = parts[0]
        val owner = if (parts.size > 1) parts[1] else ""
        val id = if (parts.size > 2) parts[2] else ""
        val web = if (name.endsWith(".html") && owner.isNotEmpty()) "https://gist.githack.com/" + owner + "/" + id + "/raw/" + name else ""
        val link = if (web.isNotEmpty()) web else url
        AlertDialog.Builder(this)
            .setTitle("게시했어요 ✅")
            .setMessage("비공개 Gist예요. 링크를 아는 사람만 볼 수 있어요.\n\n" + url + (if (web.isNotEmpty()) "\n\n웹페이지로 보는 링크(외부 서비스 githack):\n" + web else ""))
            .setPositiveButton("링크 복사") { _, _ -> copy(link) }
            .setNeutralButton("열기") { _, _ -> startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link))) }
            .setNegativeButton("닫기", null)
            .show()
    }
}
