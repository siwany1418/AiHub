# AI 허브

Claude, ChatGPT, Gemini를 한 앱에서 불러 쓰는 안드로이드 앱 (API 키 없이, 로그인된 사이트 사용).

- `@claude` / `@chatgpt` / `@gemini` + 요청 → 부른 AI만 답해요
- 둘이 토론 모드 → 서로 의견을 주고받고 최종 결과 생성
- 사용량 한도에 도달한 AI는 한 번만 알리고 건너뜀
- 코드는 파일 카드로 표시 (복사·공유)

## APK 만들기 (GitHub Actions)
1. 이 폴더 전체를 GitHub 저장소에 올려요 (`main` 브랜치).
2. 저장소의 **Actions** 탭 → **Build APK**가 자동 실행돼요 (또는 Run workflow).
3. 완료되면 실행 결과 화면 맨 아래 **Artifacts → AiHub-debug-apk**를 받아서 압축을 풀면 `app-debug.apk`가 있어요.
4. 폰/태블릿에 설치 (설정에서 '출처를 알 수 없는 앱' 허용).

## 사용
앱 실행 → ☰ → 각 AI 로그인 → 완료 → 대화 시작.
